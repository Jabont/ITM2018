let thename = prompt('What you name dude!');
document.querySelector('#show_the_name').innerHTML = thename;